
  # AlfieAI Web Dashboard Design

  This is a code bundle for AlfieAI Web Dashboard Design. The original project is available at https://www.figma.com/design/9r5BpPriYHqJHL2MW2LwWL/AlfieAI-Web-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  